﻿namespace Backbone.Modules.Devices.Application.DTOs;

public class ChallengeDTO
{
    public string Id { get; set; }
    public DateTime ExpiresAt { get; set; }
}
