﻿namespace Backbone.Modules.Devices.Application.Infrastructure.PushNotifications.ExternalEvents;

[NotificationText(Title = NotificationTextAttribute.DEFAULT_TITLE, Body = NotificationTextAttribute.DEFAULT_BODY)]
public record ExternalEventCreatedPushNotification;
