﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Devices.Application.Tests")]
