﻿namespace Backbone.Modules.Devices.API.Models;

public static class CustomClaims
{
    public const string ADDRESS = "address";
    public const string DEVICE_ID = "device_id";
}
