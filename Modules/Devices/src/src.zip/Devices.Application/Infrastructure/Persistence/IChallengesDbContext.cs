﻿using Enmeshed.BuildingBlocks.Application.Abstractions.Infrastructure.Persistence.Database;

namespace Backbone.Modules.Devices.Application.Infrastructure.Persistence;

public interface IDevicesDbContext : IDbContext
{
}
