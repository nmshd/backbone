﻿// ReSharper disable once CheckNamespace

namespace Enmeshed.BuildingBlocks.Application.Abstractions.Infrastructure.Mapping
{
    // ReSharper disable once UnusedTypeParameter
    public interface IMapTo<TEntity> { }
}
